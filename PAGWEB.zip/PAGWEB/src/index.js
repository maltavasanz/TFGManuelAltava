
function chartt(event) {
  let tiempo = [];
  let corriente = [];
  let potencial = [];  
  let splitFile = [];

  const files = event.target.files;
  if (files.length == 0) return;
  const file = files[0];

  let reader = new FileReader();
  reader.onload = (e) => {
    const file = e.target.result;
    splitFile = file.split(/\r\n|\t/);

    for (let i = 3; i < splitFile.length; i = i + 3) {
      tiempo.push(splitFile[i]);
      corriente.push(splitFile[i + 1]);
      potencial.push(splitFile[i + 2]);
    }
    
  };
  reader.onerror = (e) => alert(e.target.error.name);
  reader.readAsText(file);



const ctx = document.getElementById("myChart");
const labels = potencial;
new Chart(ctx, {
  type: "scatter",
  data: {
    labels: labels,
    datasets: [
      {
        label: "primera",
        data: corriente,
        fill: false,
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  },
  options: {
    scales: {
      y: {
        scaleLabel: {
          display: true,
          labelString: "Intensidad (A)",
          fontSize: 14,
          fontColor: '#FFF'
        }
      },
      x: {
        scaleLabel: {
          display: true,
          labelString: "Tensión (V)",
          fontSize: 14,
          fontColor: '#FFF'
        }
      }
    }
  }
});
}

